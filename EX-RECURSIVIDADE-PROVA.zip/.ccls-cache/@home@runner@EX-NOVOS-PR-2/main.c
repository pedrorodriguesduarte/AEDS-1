#include <stdio.h>

int multiplica(int primeiro , int segundo) {

  if (segundo == 0) {
    return 0;
  }

  if (segundo < 0) {
    return -multiplica(primeiro, -segundo);
  }

  return primeiro + multiplica(primeiro, segundo - 1);
}

int main() {
  int primeiro, segundo;

  printf("Digite o valor do primeiro numero: ");
  scanf("%d", &primeiro);
  printf("Digite o valor do segundo numero: ");
  scanf("%d", &segundo);

  int resultado = multiplica(primeiro, segundo);

  printf("%d multiplicado por %d é %d\n", primeiro, segundo, resultado);

  return 0;
}