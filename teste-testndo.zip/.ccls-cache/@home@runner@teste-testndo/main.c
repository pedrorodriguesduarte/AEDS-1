#include <stdio.h>

int fatorialRecursivo (int n){
  if ( n == 0 || n == 1){
    return 1;
  } else{
   return n * fatorialRecursivo (n-1); 
  }
}

int main (){
  int num;
  printf  ("\n DIGITE O VALOR DO NUMERO QUE VOCE QUER SABER O FATORIAL : ");
  scanf ("%d", &num);
  printf ("\n O VALOR DO FATORIAL DE %d E IGUAL A : %d ", num, fatorialRecursivo(num));
}