#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {

  while (1) {

    srand(time(NULL));
    int numeroSorteado = rand() % 101;
    int numeroEscolhido;
    

    
    printf("\n Escolha um numero entre 0 e 100: ");
    scanf("%d", &numeroEscolhido);

    if (numeroEscolhido == numeroSorteado) {
      printf("Parabens, voce ganhou!\n");
    } else {
      printf("Voce perdeu, o numero sorteado foi %d\n" , numeroSorteado);
    }
  }
}