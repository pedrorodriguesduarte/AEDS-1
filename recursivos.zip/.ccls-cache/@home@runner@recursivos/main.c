#include <stdio.h>
#include <stdlib.h>

int potencia(int base, int expoente) {
  if (expoente < 1) {
    return 1;
  }
  if (base < 1) {
    return 0;
  }
  return base * potencia(base, expoente - 1);
}

int main() {
  int base, expoente;

  printf("Digite o valor da base: ");
  scanf("%d", &base);
  printf("\nDigite o valor do expoente: ");
  scanf("%d", &expoente);

  int resultado = potencia(base, expoente);
  printf("\nResultado: %d\n", resultado);

  return 0;
}
